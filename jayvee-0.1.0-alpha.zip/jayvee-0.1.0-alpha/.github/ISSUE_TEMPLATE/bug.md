---
name: Bug
about: Description of the bug
title: '[BUG] <name>'
labels: bug
assignees: ''

---

## Steps to reproduce
1.

## Description
- Expected: 
- Actual:
