// SPDX-FileCopyrightText: 2023 Friedrich-Alexander-Universitat Erlangen-Nurnberg
//
// SPDX-License-Identifier: AGPL-3.0-only

import { getJestProjects } from '@nrwl/jest';

export default {
  projects: getJestProjects(),
};
