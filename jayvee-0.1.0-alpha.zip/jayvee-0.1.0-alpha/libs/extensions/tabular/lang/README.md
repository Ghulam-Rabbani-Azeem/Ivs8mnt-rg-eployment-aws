<!--
SPDX-FileCopyrightText: 2023 Friedrich-Alexander-Universitat Erlangen-Nurnberg

SPDX-License-Identifier: AGPL-3.0-only
-->

# extensions-tabular-lang

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build extensions-tabular-lang` to build the library.

## Running unit tests

Run `nx test extensions-tabular-lang` to execute the unit tests via [Jest](https://jestjs.io).
