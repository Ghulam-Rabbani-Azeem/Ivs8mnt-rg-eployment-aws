<!--
SPDX-FileCopyrightText: 2023 Friedrich-Alexander-Universitat Erlangen-Nurnberg

SPDX-License-Identifier: AGPL-3.0-only
-->

# execution

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build execution` to build the library.

## Running unit tests

Run `nx test execution` to execute the unit tests via [Jest](https://jestjs.io).
