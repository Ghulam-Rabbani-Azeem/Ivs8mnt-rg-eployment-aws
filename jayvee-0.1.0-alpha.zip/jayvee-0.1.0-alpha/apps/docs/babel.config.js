// SPDX-FileCopyrightText: 2023 Friedrich-Alexander-Universitat Erlangen-Nurnberg
//
// SPDX-License-Identifier: AGPL-3.0-only

module.exports = {
  presets: [require.resolve('@docusaurus/core/lib/babel/preset')],
};
