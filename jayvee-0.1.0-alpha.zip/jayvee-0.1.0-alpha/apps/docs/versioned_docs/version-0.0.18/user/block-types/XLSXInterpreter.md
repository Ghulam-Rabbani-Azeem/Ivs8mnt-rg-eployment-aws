---
title: XLSXInterpreter
---

<!-- Do NOT change this document as it is auto-generated from the language server -->

Input type: `File`

Output type: `Workbook`

## Description

Interprets an input file as a XLSX-file and outputs a `Workbook` containing `Sheet`s.

## Example 1

```jayvee
block AgencyXLSXInterpreter oftype XLSXInterpreter {  
  }
```

Interprets an input file as a XLSX-file and outputs a `Workbook` containing `Sheet`s.

## Properties
