---
title: TextLineDeleter
---

<!-- Do NOT change this document as it is auto-generated from the language server -->

Input type: `TextFile`

Output type: `TextFile`

## Description

Deletes individual lines from a `TextFile`.

## Properties

### `lines`

Type `collection<integer>`

#### Description

The line numbers to delete.
