---
title: TextRangeSelector
---

<!-- Do NOT change this document as it is auto-generated from the language server -->

Input type: `TextFile`

Output type: `TextFile`

## Description

Selects a range of lines from a `TextFile`.

## Properties

### `lineFrom`

Type `integer`

Default: `1`

### `lineTo`

Type `integer`

Default: `null`
